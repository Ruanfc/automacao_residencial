import sys
from projeto_gui_teste import *
from PyQt5 import QtWidgets, QtCore
import matplotlib
from matplotlib import animation
import numpy as np

matplotlib.use('QT5Agg')


x = ['Lâmpada 1', 'Lâmpada 2', 'Lâmpada 3']
y = [2, 5, 7]

class MatplotlibWidget(QtWidgets.QMainWindow):

    def __init__(self):
        super().__init__()

        # Set up the RDF
        self.RDF = Ui_RDF()
        self.RDF.setupUi(self)

        self.axes = self.RDF.mplwidget.canvas.axes

        self.axes.bar(np.array(x), np.array(y), color='g')
        self.axes.set_title('Gráfico de acionamento das lâmpadas')
        #self.axes.set_xlabel('Lâmpadas')
        self.axes.set_ylabel('Quantidade de horas')
        self.axes.set_yticks([0,1,2,3,4,5,6,7,8,9,10,11,12])
        #self.axesLeft = self.axes.twinx()
        #elf.axesLeft.plot(np.array([3,5,7,6,3,2,7]), color='tab:blue')

    
        self.ani = animation.FuncAnimation(fig, animar, interval = 1000)

        # Show
        self.show()


if __name__ == '__main__':
    app = QtWidgets.QApplication(sys.argv)
    RDF = MatplotlibWidget()
    RDF.show()
    sys.exit(app.exec_())
