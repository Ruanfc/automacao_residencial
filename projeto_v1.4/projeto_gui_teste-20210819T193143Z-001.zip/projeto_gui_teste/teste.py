import numpy as np
from gi.repository import Gtk
from gi.repository import GObject
from matplotlib.figure import Figure
from matplotlib.backends.backend_gtk3cairo import FigureCanvasGTK3Cairo as FigureCanvas
import matplotlib.pyplot as plt
import matplotlib.animation as animation

class MyApp(object):
    def __init__(self):
        window = Gtk.Window()
        window.connect("delete-event", Gtk.main_quit)
        window.set_default_size(400, 400)
        sw = Gtk.ScrolledWindow()
        window.add(sw)

        self.fig = fig = Figure()
        self.canvas = FigureCanvas(fig)
        sw.add_with_viewport(self.canvas)

        ax = fig.add_subplot(111)
        data = np.zeros(100)
        self.line, = ax.plot(data, 'r-')
        ax.set_ylim(-1, 1)
        self.ani = animation.FuncAnimation(
            self.fig, self.update_line, interval=100, frames=50, repeat=True)

        window.show_all()

    def update_line(self, *args):
        data = 2*(np.random.random(100)-0.5)
        self.line.set_ydata(data)
        self.canvas.draw()
        return True

if __name__ == "__main__":
    app = MyApp()
    Gtk.main()