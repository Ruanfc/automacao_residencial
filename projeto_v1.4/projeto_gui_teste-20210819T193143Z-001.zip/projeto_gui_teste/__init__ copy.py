import sys
from projeto_gui_teste import *
from PyQt5 import QtWidgets, QtCore
import matplotlib
import matplotlib.pyplot as plt 
from mplwidget_copy import MplWidget
from matplotlib import animation
import numpy as np

matplotlib.use('QT5Agg')


x = ['Lâmpada 1', 'Lâmpada 2', 'Lâmpada 3', 'Lâmpada 4']
y = [2, 5, 7, 4]

class MatplotlibWidget(QtWidgets.QMainWindow):

    def __init__(self):
        super().__init__()

        # Set up the RDF
        self.RDF = Ui_RDF()
        self.RDF.setupUi(self)
        self.graficos()
       
    
    def graficos(self):
        with open('dados.txt', 'r') as f:
            dados = f.read()

        x = []
        y = []

        for linha in dados.split('\n'):
            if len(linha) == 0:
                continue
            xi, yi = linha.split(',')
            x.append(float(xi))
            y.append(float(yi))
          
        self.axes = self.RDF.mplwidget.canvas.axes

        self.axes.bar(np.array(x), np.array(y), color='g')
        self.axes.set_title('Gráfico de acionamento das lâmpadas')
        #self.axes.set_xlabel('Lâmpadas')
        self.axes.set_ylabel('Quantidade de horas')
        self.axes.set_yticks([0,1,2,3,4,5,6,7,8,9,10,11,12])
        #self.ani = animation.FuncAnimation(self.fig, self.graficos, interval = 1000)
        

    
    #ani = animation.FuncAnimation(lambda: fig, graficos, interval = 1000)
    #self.show()



    ''' def animar(self, i):
        with open('dados.txt', 'r') as f:
        dados = f.read()

        x = []
        y = []

        for linha in dados.split('\n'):
            if len(linha) == 0:
                continue
            xi, yi = linha.split(',')
            x.append(float(xi))
            y.append(float(yi))
        ax.clear()
        ax.plot(x,y)
        ax.set_xlabel('Eixo x')
        #plt.savefig('grafico_tempo_real/grafico_tempo_real.png', dpi =100) #salva uma imagem do grafico


    self.ani = animation.FuncAnimation(fig, animar, interval = 1000)

        # Show '''
        #self.show()


'''     def animate(self, i):
        self.x = ['Lâmpada 1', 'Lâmpada 2', 'Lâmpada 3']
        self.y = [2, 5, 7]

        self.plt.cla()
        self.plt(x,y)
    self.ani = animation.FuncAnimation(lambda: plt.gcf(), animate, interval = 1000)

    self.plt.show() '''
    

if __name__ == '__main__':
    app = QtWidgets.QApplication(sys.argv)
    RDF = MatplotlibWidget()
    #graficos() 
    RDF.show()
    sys.exit(app.exec_())
    tela.btn_grafico.clicked.connect(graficos())